﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReproductorAudios
{
    public partial class AgendarEntrevistas : Form
    {
        private readonly Form1 _parent;

        public AgendarEntrevistas()
        {
            InitializeComponent();
        }


        public AgendarEntrevistas(Form1 parent)
        {
            InitializeComponent();
            _parent = parent;
        }

        public void Clear()
        {
            txtResumen.Text = txtFechaEntrevista.Text = txtLugar.Text = txtEntrevistado.Text = txtEntrevistador.Text = string.Empty ;
        }


        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtResumen.Text.Trim().Length < 25)
            {
                MessageBox.Show("El Resumen debe tener al menos 25 caracteres.");
                return;
            }
            if (txtFechaEntrevista.Text.Trim().Length < 10) // Cambiado a 10 para incluir la longitud de "dd/MM/yyyy"
            {
                MessageBox.Show("La Fecha Entrevista debe tener el formato dd/MM/yyyy.");
                return;
            }
            if (txtLugar.Text.Trim().Length < 5)
            {
                MessageBox.Show("El Lugar debe tener al menos 5 caracteres.");
                return;
            }
            if (txtEntrevistado.Text.Trim().Length < 5)
            {
                MessageBox.Show("El Entrevistado debe tener al menos 5 caracteres.");
                return;
            }
            if (txtEntrevistador.Text.Trim().Length < 5)
            {
                MessageBox.Show("El Entrevistador debe tener al menos 5 caracteres.");
                return;
            }

            if (btnGuardar.Text == "Guardar")
            {
                if (DateTime.TryParseExact(txtFechaEntrevista.Text.Trim(), "dd/MM/yyyy", null, DateTimeStyles.None, out DateTime fechaEntrevista))
                {
                    // Convertir fecha al formato de MySQL ('YYYY-MM-DD')
                    string fechaMySQL = fechaEntrevista.ToString("yyyy-MM-dd");

                    // Query SQL con DATE_FORMAT para formatear la fecha al formato dd/MM/yyyy
                    string query = $"INSERT INTO tu_tabla (Resumen, FechaEntrevista, Lugar, Entrevistado, Entrevistador) VALUES ('{txtResumen.Text.Trim()}', DATE_FORMAT('{fechaMySQL}', '%d/%m/%Y'), '{txtLugar.Text.Trim()}', '{txtEntrevistado.Text.Trim()}', '{txtEntrevistador.Text.Trim()}')";

                    DbEntrevistas.ExecuteQuery(query);
                    Clear();
                }
                else
                {
                    MessageBox.Show("Formato de fecha incorrecto. Por favor, ingrese una fecha válida en el formato dd/MM/yyyy.");
                }
            }

            _parent.Display();
        }
        public static class DbEntrevistas
        {
            public static void ExecuteQuery(string query)
            {
                MySqlConnection con = GetConnection();
                con.Open();

                using (MySqlCommand cmd = new MySqlCommand(query, con))
                {
                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Consulta ejecutada con éxito.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("La consulta no se pudo ejecutar. \n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }

            public static MySqlConnection GetConnection()
            {
                // Implementa el código para obtener y devolver la conexión a la base de datos.
            }
        }



        private void AgendarEntrevistas_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
