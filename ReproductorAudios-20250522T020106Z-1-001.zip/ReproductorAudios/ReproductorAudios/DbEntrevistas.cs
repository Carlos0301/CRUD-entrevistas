﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReproductorAudios
{
    internal class DbEntrevistas
    {
        public static MySqlConnection GetConnection()
        {
            string sql = "datasource=localhost;port=3306;username=root;password=;database=audio";
            MySqlConnection con = new MySqlConnection(sql);
            try
            {
                con.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySQL Connection! \n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return con;
        }


        public static void AgendarEntrevistas(Entrevistas std)
        {
            string sql = "INSERT INTO entrevistas (Resumen, FechaEntrevista, Lugar, Entrevistado, Entrevistador) VALUES (@AgendarEntrevistasResumen, @AgendarEntrevistasFechaEntrevista, @AgendarEntrevistasLugar, @AgendarEntrevistasEntrevistado, @AgendarEntrevistasEntrevistador)";

            using (MySqlConnection con = GetConnection())
            {
                using (MySqlCommand cmd = new MySqlCommand(sql, con))

                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add("@AgendarEntrevistasResumen", MySqlDbType.VarChar).Value = std.Resumen;
                    cmd.Parameters.Add("@AgendarEntrevistasFechaEntrevista", MySqlDbType.Date).Value = std.FechaEntrevista;
                    cmd.Parameters.Add("@AgendarEntrevistasLugar", MySqlDbType.VarChar).Value = std.Lugar;
                    cmd.Parameters.Add("@AgendarEntrevistasEntrevistado", MySqlDbType.VarChar).Value = std.Entrevistado;
                    cmd.Parameters.Add("@AgendarEntrevistasEntrevistador", MySqlDbType.VarChar).Value = std.Entrevistador;

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Added Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Entrevista not insert. \n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        public static void GuardarEntrevistas(Entrevistas std, string id)
        {
            string sql = "UPDATE entrevistas SET Resumen = @AgendarEntrevistasResumen, FechaEntrevista = @AgendarEntrevistasFechaEntrevista, Lugar = @AgendarEntrevistasLugar, Entrevistado = @AgendarEntrevistasEntrevistado, Entrevistador = @AgendarEntrevistasEntrevistador WHERE ID = @AgendarEntrevistasID";

            MySqlConnection con = GetConnection();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@AgendarEntrevistasResumen", MySqlDbType.VarChar).Value = std.Resumen;
            cmd.Parameters.Add("@AgendarEntrevistasFechaEntrevista", MySqlDbType.Date).Value = std.FechaEntrevista;
            cmd.Parameters.Add("@AgendarEntrevistasLugar", MySqlDbType.VarChar).Value = std.Lugar;
            cmd.Parameters.Add("@AgendarEntrevistasEntrevistado", MySqlDbType.VarChar).Value = std.Entrevistado;
            cmd.Parameters.Add("@AgendarEntrevistasEntrevistador", MySqlDbType.VarChar).Value = std.Entrevistador;
            cmd.Parameters.Add("@AgendarEntrevistasID", MySqlDbType.VarChar).Value = id;

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Entrevista not update. \n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            con.Close();
        }

        public static void BorrarEntrevistas(string id)
        {
            string sql = "DELETE FROM entrevistas WHERE ID = @AgendarEntrevistasID";
            MySqlConnection con = GetConnection();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@AgendarEntrevistasID", MySqlDbType.VarChar).Value = id;
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Entrevista not delete. \n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            con.Close();
        }
        public static void DisplayandSearch(string query, DataGridView dgv)
        {
            string sql = query;
            MySqlConnection con = GetConnection();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable tbl = new DataTable();
            //adp.Fill(tbl);
            con.Close();
        }

        internal static void Display(string v, DataGridView dataGridView)
        {

        }

        internal static void ExecuteQuery(string query)
        {
            using (MySqlConnection con = GetConnection())
            {
                using (MySqlCommand cmd = new MySqlCommand(query, con))
                {
                    con.Open();
                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Query executed Successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Query not executed. \n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }    
}



