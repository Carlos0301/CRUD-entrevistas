﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReproductorAudios
{
    internal class Entrevistas
    {
        private string v1;
        private string fechaMySQL;
        private string v2;
        private string v3;
        private string v4;

        public string Resumen { get; set; }
        public DateTime FechaEntrevista  { get; set; }
        public string Lugar { get; set; }
        public string Entrevistado { get; set; }
        public string Entrevistador { get; set; }

        public Entrevistas(string resumen, DateTime fechaEntrevista, string lugar, string entrevistado, string entrevistador)
        {
            Resumen = resumen;
            FechaEntrevista = fechaEntrevista;
            Lugar = lugar;
            Entrevistado = entrevistado;
            Entrevistador = entrevistador;
        }

        public Entrevistas(string v1, string fechaMySQL, string v2, string v3, string v4)
        {
            this.v1 = v1;
            this.fechaMySQL = fechaMySQL;
            this.v2 = v2;
            this.v3 = v3;
            this.v4 = v4;
        }
    }
}
